CXSparse/Source directory: primary ANSI C source code files for CXSparse.
To compile the libcxsparse.a C-callable library, just type "make" in this
directory.

Timothy A. Davis, http://www.suitesparse.com
