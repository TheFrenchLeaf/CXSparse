#include "cs.h"
#define malloc_count CS_NAME (_malloc_count)
#ifndef EXTERN
#define EXTERN extern
#endif
EXTERN int malloc_count ;

