function x = cs_ipvec (b,p)                                                 %#ok
%CS_IPVEC x(p)=b
%
% Example:
%   x = cs_ipvec (b,p)
% See also: cs_demo

% Copyright 2006-2012, Timothy A. Davis, http://www.suitesparse.com

error ('cs_ipvec mexFunction not found') ;

