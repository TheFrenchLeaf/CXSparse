function A = cs_sparse2 (i,j,x)                                             %#ok
%CS_SPARSE2 same as cs_sparse, to test cs_entry function
% A = cs_sparse2 (i,j,x), removing duplicates and numerically zero entries,
% and returning A sorted (test cs_entry)
%
% Example:
%   A = cs_sparse2 (i,j,x)
% See also: cs_demo

% Copyright 2006-2012, Timothy A. Davis, http://www.suitesparse.com

error ('cs_sparse2 mexFunction not found') ;

